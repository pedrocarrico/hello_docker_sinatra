# hello docker sinatra

```bash
docker build -t hello_docker_sinatra .
docker run -p 3000:3000 hello_docker_sinatra
```
